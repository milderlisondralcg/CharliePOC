﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using DMP.Models.ViewModel;
using DMP.Models.EntityManager;
using DMP.Models.DB;

namespace DMP.Controllers
{
    public class AccountController : Controller
    {
        DMPEntities db = new DMPEntities();

        // GET: Account
        public ActionResult AddUser()
        {
            return View();
        }


        [HttpPost]
        public ActionResult AddUser(AddUserSignUpView USV)
        {
            if (ModelState.IsValid)
            {
                UserManager UM = new UserManager();
                if (!UM.IsLoginNameExist(USV.LoginName))
                {
                    UM.AddUserAccount(USV);
                    //FormsAuthentication.SetAuthCookie(USV.FirstName, false);
                    return RedirectToAction("Welcome", "Home");

                }
                else
                    ModelState.AddModelError("", "Login Name already taken.");
            }
            return View();
        }


        public ActionResult LogIn()
        {
            return View();
        }

        [HttpPost]
        public ActionResult LogIn(UserLoginView ULV, string returnUrl)
        {
            // ModelState.IsValid is the check for all required fields
            if (ModelState.IsValid)
            {
                UserManager UM = new UserManager(); // create instance of UserManager class
                string password = UM.GetUserPassword(ULV.LoginName); // password from database

                int userId = UM.GetUserID(ULV.LoginName);
                Session["loggedInUser"] = userId;

                if (string.IsNullOrEmpty(password))
                    ModelState.AddModelError("", "The username or password provided is incorrect.");
                else
                {
                    // Debugging
                    string hashed_input = UM.CreateMD5Hash(ULV.Password);

                    //if (ULV.Password.Equals(password))
                    if(hashed_input.Equals(password))
                    {
                        FormsAuthentication.SetAuthCookie(ULV.LoginName, false);
                        return RedirectToAction("Welcome", "Home");
                    }
                    else
                    {
                        ModelState.AddModelError("", "The password provided is incorrect.");
                    }
                }
            }

            // If we got this far, something failed, redisplay form
            return View(ULV);
        }

        [Authorize]
        public ActionResult SignOut()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }
    }
}