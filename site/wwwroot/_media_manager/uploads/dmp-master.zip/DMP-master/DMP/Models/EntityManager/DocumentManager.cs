﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DMP.Models.DB;
using DMP.Models.ViewModel;
using CoherentDMP.DMP.Models.DB;

namespace DMP.Models.EntityManager
{
    public class DocumentManager
    {
        DMPEntities db = new DMPEntities();

        public void AddAppCode()
        {
            AppCodes code = new AppCodes();
            code.Code = "Milder007";
            db.AppCodes.Add(code);
            db.SaveChanges();
     
            
        }

        public int AddDocument(UpdateDocumentView document)
        {

            Document Doc = new Document();
            Doc.Title = document.Title;
            Doc.Description = document.Description;
            Doc.Category = document.Category;
            Doc.Tags = document.Tags;
            Doc.SalesForceId = document.SalesForceId;
            Doc.AlternateTrackingId = document.AlternateTrackingId;
            Doc.EndpointURL = document.EndpointURL;
            Doc.CreatedDateTime = DateTime.Now;
            Doc.ModifiedDateTime = DateTime.Now;
            Doc.FileName = document.Filename;
            Doc.LeadRequired = document.LeadRequired.Trim();
            Doc.EmailNotify = document.EmailNotify;
            Doc.CreatedBy = document.CreatedBy;
            Doc.AppCode = document.AppCode;
            Doc.ProductGroup = document.ProductGroup;
            db.Documents.Add(Doc);
            db.SaveChanges();

            return Doc.Id;
        }
        
        public void EditDocument(UpdateDocumentView document)
        {

            Document Doc = new Document();
            Doc.Title = document.Title;
            Doc.Description = document.Description;
            Doc.Category = document.Category;
            Doc.Tags = document.Tags;
            Doc.SalesForceId = document.SalesForceId;
            Doc.AlternateTrackingId = document.AlternateTrackingId;
            Doc.EndpointURL = document.EndpointURL;
            Doc.CreatedDateTime = DateTime.Now;
            Doc.ModifiedDateTime = DateTime.Now;
            Doc.FileName = document.Filename;
            Doc.LeadRequired = document.LeadRequired.Trim();
            Doc.EmailNotify = document.EmailNotify;
            Doc.CreatedBy = document.CreatedBy;
            db.Documents.Add(Doc);
            db.SaveChanges();

        }

        public void DeleteDocument(int documnentId)
        {
            using (var dbContextTransaction = db.Database.BeginTransaction())
            try
            {
               
                var doc = db.Documents.Where(o => o.Id == documnentId);
                if (doc.Any())
                {
                    db.Documents.Remove(doc.FirstOrDefault());
                    db.SaveChanges();
                }

                dbContextTransaction.Commit();
            }
            catch
            {
                dbContextTransaction.Rollback();
            }
        }

        public Document GetDocument( int documentId)
        {
            var doc = db.Documents.Find(documentId);
            return doc;
        }

        public object GetAppCodes()
        {
            var appCodes = db.AppCodes.ToList();
            return appCodes;
        }

    }


}