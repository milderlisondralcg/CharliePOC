### Which service(blob, file, queue, table) does this issue concern?


### Which version of the SDK was used?


### What's the PHP/OS version?


### What problem was encountered?


### Steps to reproduce the issue?


### Have you found a mitigation/solution?
