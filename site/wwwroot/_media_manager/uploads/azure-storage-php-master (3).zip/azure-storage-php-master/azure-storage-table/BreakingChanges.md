Tracking Breaking changes in 1.0.0

* Removed `dataSerializer` parameter from `TableRextProxy` constructor.
* Will change variable type according to EdmType specified when serializing table entity values.
* Deprecated PHP 5.5 support.