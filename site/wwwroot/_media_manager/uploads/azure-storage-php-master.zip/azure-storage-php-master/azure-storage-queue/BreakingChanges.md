Tracking Breaking changes in 1.0.0

* Removed `dataSerializer` parameter from `QueueRextProxy` constructor.
* Deprecated PHP 5.5 support.