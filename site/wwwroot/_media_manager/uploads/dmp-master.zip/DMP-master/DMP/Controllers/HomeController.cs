﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using DMP.Models.ViewModel;
using DMP.Models.EntityManager;
using DMP.Security;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Collections.Generic;

//using System.Web.Script.Serialization;
//using Newtonsoft.Json;
//using System.Configuration;
//using System.Xml;
//using System.Xml.Linq;

namespace DMP.Controllers
{
    public class HomeController : Controller
    {


        // GET: Home
        public ActionResult Index()
        {
            return RedirectToAction("Welcome", "Home");

        }

        //[Authorize]
        public ActionResult Welcome()
        {
            if (User.Identity.IsAuthenticated)
            {
                Session["LoggedIn"] = "yes";
                ViewBag.LoggedIn = "yes";
                return View();
            }
            else
            {
                return RedirectToAction("Login","Account");
            }
                
        }

        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            Session.Abandon(); // it will clear the session at the end of request
            return RedirectToAction("Index", "Home");
        }

        //[AuthorizeRoles("Admin")]
        public ActionResult AdminOnly()
        {
            return View();
        }

        public ActionResult UnAuthorized()
        {
            return View();
        }

        [AuthorizeRoles("Admin")]
        public ActionResult ManageUserPartial(string status = "")
        {
            if (User.Identity.IsAuthenticated)
            {
                string loginName = User.Identity.Name;
                
                UserManager UM = new UserManager();
                UserDataView UDV = UM.GetUserDataView(loginName);

                string message = string.Empty;
                if (status.Equals("update"))
                    message = "Update Successful";
                else if (status.Equals("delete"))
                    message = "Delete Successful";

                ViewBag.Message = message;
                return PartialView(UDV);
            }

            return RedirectToAction("Index", "Home");
        }


        [AuthorizeRoles("Admin")]
        public ActionResult UpdateUserData(int userID, string loginName, string password, string firstName, string lastName, string gender, int roleID = 0)
        {
            UserProfileView UPV = new UserProfileView();
            UPV.SYSUserID = userID;
            UPV.LoginName = loginName;
            UPV.Password = password;
            UPV.FirstName = firstName;
            UPV.LastName = lastName;
            UPV.Gender = gender;

            
            if (roleID > 0)
                UPV.LOOKUPRoleID = roleID;

            UserManager UM = new UserManager();
            UM.UpdateUserAccount(UPV);

            return Json(new { success = true });
 
        }

        [AuthorizeRoles("Admin")]
        public ActionResult DeleteUser(int userID)
        {
            UserManager UM = new UserManager();
            UM.DeleteUser(userID);
            return Json(new { success = true });
        }

        //Auth point for EE
      
        public async Task<ActionResult> AuthEE(string uniqueid, string ipaddress)
        {

            if (uniqueid != null )
            {
                HttpClient client = new HttpClient();
                string ee_URL = "https://charlie.coherent.com/dmp/verify.php?id=" + uniqueid;

                var response = client.GetAsync(ee_URL).Result;

                string responseData = response.Content.ReadAsStringAsync().Result;

                MyContacts contacts = JsonConvert.DeserializeObject<MyContacts>(responseData);

                if (contacts.auth == "yes")
                {
                    Session["group"] = contacts.group;
                    Session["userid"] = contacts.user_id;
                    Session["username"] = contacts.username.Trim();
                    FormsAuthentication.SetAuthCookie("admin", false);
                    return RedirectToAction("Welcome", "Home");
                }
                return Content(contacts.auth);
            }
            else
            {
                return Content("You are not authenticated in Expression Engine. Please go back to Expression Engine and authenticate.");
            }
        }

        public class MyContacts
        {
            public string auth { get; set; }
            public int group { get; set; }
            public int user_id { get; set; }
            public string username { get; set; }
            
        }

        /*
         Name: Milder,
         Gender: Male

            addresses[0]: 60 haight street
            addresses[1]: 2070 tomales bay drive


             */


        
        public async Task<ActionResult> AuthEEDebug(string uniqueid, string ipaddress)
        {

            if (uniqueid != null )
            {
                HttpClient client = new HttpClient();
                // string ee_URL = "http://charlie.coherent.com/includes/userinfo2?id=" + uniqueid + "&ip=" + ipaddress + "/";
                string ee_URL = "https://charlie.coherent.com/test.php?id=" + uniqueid;
                //string ee_URL = @"https://charlie.coherent.com/dmp.test.php";

                var response = client.GetAsync(ee_URL).Result;

               string responseData = response.Content.ReadAsStringAsync().Result;

                MyContacts contacts = JsonConvert.DeserializeObject<MyContacts>(responseData);

                if(contacts.auth == "yes")
                {
                    FormsAuthentication.SetAuthCookie("admin", false);
                    return RedirectToAction("Welcome", "Home");
                }
                return Content(contacts.auth);
             //   MyContacts test = new MyContacts();
              //  test.Name = "Milder";
              //  test.Gender = "Male";

               // test.addresses.Add(new MyAddress {streetName = "60 Haight street" });
               // test.addresses.Add(new MyAddress { streetName = "2070 Tomales bay dr" });
               // test.addresses.Add(new MyAddress { streetName = "6045 Sacramento ave." });

                //string myContactsSerialized = JsonConvert.SerializeObject(test);


                //MyContacts myConstactsDeserialized = JsonConvert.DeserializeObject<MyContacts>(myContactsSerialized);


               
            }
            else
            {
                return Content("you are not logged into Expression Engine");
            }
        }



    }
}