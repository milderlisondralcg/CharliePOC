﻿using System;
using System.Net;
using System.Net.Mail;
using System.Net.Sockets;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DMP.Models.DB;
using DMP.Models.ViewModel;
using System.Globalization;
using CoherentDMP.DMP.Models.DB;

namespace DMP.Models.EntityManager
{
    public class LeadsManager
    {
        DMPEntities db = new DMPEntities();

        public object GetLeadUser(string emailAddress)
        {
            return db.Leads.SingleOrDefault(x => x.Email == emailAddress);

        }
        public int AddLead( AddLeadsView lead)
        {

            Leads Lead = new Leads();
            Lead.FirstName = lead.FirstName;
            Lead.LastName = lead.LastName;
            Lead.Email = lead.Email;
            Lead.Phone = lead.Phone;
            Lead.Organization = lead.Organization;
            Lead.Country = lead.Country;
            Lead.IpAddress = Lead.IpAddress;
            Lead.CreatedDatetime = DateTime.Now;
            //Lead.UID = Guid.NewGuid().ToString();
            db.Leads.Add(Lead);
            db.SaveChanges();
            return Lead.Id;
        }

        public void SendNotification( Dictionary<string,string> notificationInfo )
        {
            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com", 25);

            smtpClient.Credentials = new System.Net.NetworkCredential("milderhlisondra@gmail.com", "025Zeus!Pinoy");
            smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtpClient.EnableSsl = true;
            MailMessage mail = new MailMessage();

            mail.Subject = notificationInfo["subject"];
            mail.Body = notificationInfo["message"]; ;
            mail.IsBodyHtml = true;
            //Setting From , To and CC
            mail.From = new MailAddress("milderhlisondra@gmail.com", "Coherent Document Management Portal");
            mail.To.Add(new MailAddress(notificationInfo["recipient"]));
            if (notificationInfo["recipientCC"] != null)
            {
                mail.To.Add(new MailAddress(notificationInfo["recipientCC"]));
            }
            smtpClient.Send(mail);

        }

        // Add new record for lead download
        public void AddLeadsDownloads(int leadId, int documentId, string documentTitle, string appCode, string productGroup)
        {
            LeadsDownloads newLeadDownload = new LeadsDownloads();
            newLeadDownload.UID = leadId;
            newLeadDownload.DocumentId = documentId;
            Document docInfo = db.Documents.Find(documentId);
            newLeadDownload.CreatedDatetime = DateTime.Now;
            newLeadDownload.DocumentTitle = documentTitle;
            newLeadDownload.UserIpAddress = GetUserIp();
            newLeadDownload.SentStatus = "No";
            newLeadDownload.AppCode = appCode;
            newLeadDownload.ProductGroup = productGroup;
            db.LeadsDownloads.Add(newLeadDownload);
            db.SaveChanges();
        }

        public HttpCookie CreateCoherentCookie( string email )
        {
            HttpCookie CoherentCookies = new HttpCookie("coherentdmp");
            CoherentCookies.Values.Add("user",email);
            CoherentCookies.Values.Add("preauthorize", "yes");
            CoherentCookies.Expires = DateTime.Now.AddHours(1);
            return CoherentCookies;
        }

        public string GetUserIp()
        {
            string ipAddress = "";
            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            ipAddress = Convert.ToString(ipHostInfo.AddressList.FirstOrDefault(address => address.AddressFamily == AddressFamily.InterNetwork));

            return ipAddress;
        }

        // Return Information for a country with the given ISO Country code ( ie. US for United States )
        public RegionInfo GetCountryInfo( string countryCode)
        {
            RegionInfo countryObj = new RegionInfo(countryCode);
            return countryObj;
        }

    }
}