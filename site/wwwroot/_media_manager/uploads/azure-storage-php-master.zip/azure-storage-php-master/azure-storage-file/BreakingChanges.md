Tracking Breaking changes in 1.0.0

* Removed `dataSerializer` parameter from `FileRextProxy` constructor.
* Option parameter type of `FileRestProxy::CreateFileFromContent` changed and added `setUseTransactionalMD5` method.
* Deprecated PHP 5.5 support.