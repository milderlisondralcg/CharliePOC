WaveMaster LabVIEW examples - version 1.1

Two identical copies of these LabVIEW examples have been saved for different versions of LabVIEW.
One copy for LabVIEW 2012 and one copy for LabVIEW 8.6.
The 2012 copy should work with LabVIEW versions 2012 and newer.
If using a version of LabVIEW prior to 2012, the 8.6 copy should be used.
If working with a version of LabVIEW prior to 8.6, please contact Coherent for support.

Notes have been added in each VI to describe the basic functions of the VIs.
These examples should work with either the RS232 port or USB serial port on the WaveMaster meters.