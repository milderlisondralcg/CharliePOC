﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using DMP.Models.ViewModel;
using DMP.Models.EntityManager;
using System.Configuration;

using DMP.Models.DB;

using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System.Net.Mail;
using System.Data.SqlClient;
using System.Collections.Specialized;
using System.Net.Http;
using CoherentDMP.DMP.Models.DB;

namespace DMP.Controllers
{
    public class LeadsController : Controller
    {
        DMPEntities db = new DMPEntities();

        // GET: Leads
        public ActionResult Index()
        {
            return View("DocumentNotFound");
        }

        // GET: Leads/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Leads/Create
        public ActionResult Create(int id)
        {
            // Document info
            Document doc = db.Documents.Find(id);
            if (doc == null)
            {
                return View("DocumentNotFound");
            }

            // check to see if this user has preauthorized downloads in the past
            HttpCookie coherentcookie = new HttpCookie("coherentdmp");
            coherentcookie = Request.Cookies["coherentdmp"];


            if (coherentcookie != null)
            {
                string authorized = Request.Cookies["coherentdmp"]["preauthorize"];
                if (authorized == "yes") // automatically redirect user to download document
                {
                    string useremail = Request.Cookies["coherentdmp"]["user"];

                    // need to search for user using email address
                    // get the id for the user and do the following
                    Leads leadUserInfo = db.Leads.Where(x => x.Email == useremail).FirstOrDefault();
                    LeadsManager LeadsManager = new LeadsManager(); // instance for LeadsManager
                    var leadUserId = leadUserInfo.Id;
                    LeadsManager.AddLeadsDownloads(leadUserId, id, doc.Title, doc.AppCode, doc.ProductGroup);
                    TempData["documentId"] = id;
                    TempData["documentTitle"] = doc.Title;
                    TempData["leadId"] = leadUserId;
                    return View("ThankYou");
                }
                else
                {
                    //its possible that the user deleted some of our cookies
                    //Document doc = db.Documents.Find(id);
                    ViewBag.DocId = doc.Id;
                    ViewBag.DocTitle = doc.Title;
                    return View();
                }
            } else {

                //Document doc = db.Documents.Find(id);
                if (doc.LeadRequired.Trim() == "Yes")
                {
                    ViewBag.DocId = doc.Id;
                    ViewBag.DocTitle = doc.Title;
                    IList<SelectListItem> CountriesList = new List<SelectListItem>
            {
                new SelectListItem{Text = "United States", Value = "B"},
                new SelectListItem{Text = "Canada", Value = "B"},
                new SelectListItem{Text = "United Kingdom", Value = "B"},
                new SelectListItem{Text = "Texas", Value = "B"},
                new SelectListItem{Text = "Washington", Value = "B"}

            };

                    ViewBag.Countries = CountriesList;
                    return View();
                } else
                {
                    LeadsManager LeadsManager = new LeadsManager(); // instance for LeadsManager
                    var leadUserId = 0;
                    LeadsManager.AddLeadsDownloads(leadUserId, id, doc.Title, doc.AppCode, doc.ProductGroup);
                    TempData["documentId"] = id;
                    TempData["documentTitle"] = doc.Title;
                    TempData["leadId"] = leadUserId;
                    return View("ThankYou");
                }

            }

        }

        public ActionResult NewAction()
        {
            var leadId = TempData["leadId"];
            var documentid = TempData["documentId"];

            Document doc = db.Documents.Find(documentid);
            var downloadFileName = "";
            var docTitle = doc.Title.Replace(" ", "");

            CloudStorageAccount coherentStorageAccount = BlobConnectionString.GetConnectionString();
            CloudBlobClient blobClient = coherentStorageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference(doc.Category);

            CloudBlockBlob blockBlob = container.GetBlockBlobReference(doc.FileName);
            if (blockBlob.Properties.ContentType == "application/pdf")
            {
                downloadFileName = docTitle + ".pdf";
            }
            else if (blockBlob.Properties.ContentType == "application/zip")
            {
                downloadFileName = docTitle + ".zip";
            }

            var sasToken = blockBlob.GetSharedAccessSignature(new SharedAccessBlobPolicy()
            {
                Permissions = SharedAccessBlobPermissions.Read,
                SharedAccessExpiryTime = DateTimeOffset.UtcNow.AddMinutes(15),
            }, new SharedAccessBlobHeaders()
            {
                ContentDisposition = "attachment; filename=\"" + downloadFileName + "\"",
            });


            // force download
            MemoryStream memStream = new MemoryStream();
            blockBlob.DownloadToStream(memStream);
            Response.ContentType = blockBlob.Properties.ContentType;
            if (blockBlob.Properties.ContentType == "application/pdf")
            {
                downloadFileName = docTitle + ".pdf";
            }
            else if (blockBlob.Properties.ContentType == "application/zip")
            {
                downloadFileName = docTitle + ".zip";
            }
            Response.AddHeader("Content-Disposition", "Attachment; filename=" + downloadFileName);
            Response.AddHeader("Content-Length", blockBlob.Properties.Length.ToString());
            Response.BinaryWrite(memStream.ToArray());


            return View("ThankYou");
        }

        // POST: Leads/Create
        [HttpPost]
        public ActionResult Create(AddLeadsView lead)
        {
            LeadsManager LeadsManager = new LeadsManager(); // instance for LeadsManager


            if (Request.Form["preauthorize"] == "yes")
            {
                //    // create cookie; pass email address given
                Response.Cookies.Add(LeadsManager.CreateCoherentCookie(lead.Email));
            }

            try
            {

                var documentid = Convert.ToInt32(Request.Form["DocId"]);
                Document doc = db.Documents.Find(documentid);

                // Check to see if user already exists using email address
                Leads leadUserInfo = db.Leads.Where(x => x.Email == lead.Email).FirstOrDefault();

                // email does not exist; Add new Lead record
                if (leadUserInfo == null)
                {
                    //LeadsManager Lead = new LeadsManager();
                    var lead_id = LeadsManager.AddLead(lead);
                    TempData["documentId"] = documentid;
                    TempData["leadId"] = lead_id;

                    leadUserInfo = db.Leads.Where(x => x.Id == lead_id).FirstOrDefault();
                    var leadUserId = leadUserInfo.Id;
                    LeadsManager.AddLeadsDownloads(leadUserId, documentid, doc.Title, doc.AppCode, doc.ProductGroup);
                    return View("ThankYou");
                }
                else {
                    // take the user id and the document id and add to dbo.LeadsDownloads
                    var leadUserId = leadUserInfo.Id;
                    //LeadsManager leadManager = new LeadsManager();
                    LeadsManager.AddLeadsDownloads(leadUserId, documentid, doc.Title, doc.AppCode, doc.ProductGroup);
                    TempData["documentId"] = documentid;
                    TempData["leadId"] = leadUserId;
                    return View("ThankYou");
                }


            }
            catch
            {
                throw;
            }
        }


        public ActionResult DownloadFile(int? id)
        //public ActionResult DownloadFile()
        {

            //return Content(id.ToString());
            if ( id != null)
            {
                TempData["documentId"] = id;
            }

                Document doc = db.Documents.Find(Convert.ToInt32(TempData["documentId"]));
                Leads lead = db.Leads.Find(Convert.ToInt32(TempData["leadId"]));



            var downloadFileName = "";
            var docTitle = doc.Title.Replace(" ", "");
            var emailToNotify = doc.EmailNotify;

            CloudStorageAccount coherentStorageAccount = BlobConnectionString.GetConnectionString();
            CloudBlobClient blobClient = coherentStorageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference(doc.Category);

            CloudBlockBlob blockBlob = container.GetBlockBlobReference(doc.FileName);
            blockBlob.FetchAttributes(); // Needed in order to attain the content type of blob to be downloaded

            if (blockBlob.Properties.ContentType == "application/pdf")
            {
                downloadFileName = docTitle + ".pdf";
            }
            else if (blockBlob.Properties.ContentType == "application/x-zip-compressed" || blockBlob.Properties.ContentType == "application/zip")
            {
                downloadFileName = docTitle + ".zip";
            }

            var sasToken = blockBlob.GetSharedAccessSignature(new SharedAccessBlobPolicy()
            {
                Permissions = SharedAccessBlobPermissions.Read,
                SharedAccessExpiryTime = DateTimeOffset.UtcNow.AddMinutes(15),
            }, new SharedAccessBlobHeaders()
            {
                ContentDisposition = "attachment; filename=\"" + downloadFileName + "\"",
            });
            var downloadUrl = string.Format("{0}{1}", blockBlob.Uri.AbsoluteUri, sasToken);//This URL will always do force download.

            MemoryStream memStream = new MemoryStream();
            blockBlob.DownloadToStream(memStream);
            Response.ContentType = blockBlob.Properties.ContentType;
            if (blockBlob.Properties.ContentType == "application/pdf")
            {
                downloadFileName = docTitle + ".pdf";
            }
            else if (blockBlob.Properties.ContentType == "application/zip")
            {
                downloadFileName = docTitle + ".zip";
            }
            else if (blockBlob.Properties.ContentType == "image/png" )
            {
                downloadFileName = docTitle + ".png";
            }
            else if (blockBlob.Properties.ContentType == "image/gif")
            {
                downloadFileName = docTitle + ".gif";
            }
            else if (blockBlob.Properties.ContentType == "image/jpg" || blockBlob.Properties.ContentType == "image/jpeg")
            {
                downloadFileName = docTitle + ".jpg";
            }
            else if (blockBlob.Properties.ContentType == "text/html")
            {
                downloadFileName = docTitle + ".html";
            }
            else if (blockBlob.Properties.ContentType == "text/csv")
            {
                downloadFileName = docTitle + ".csv";
            }
            else if (blockBlob.Properties.ContentType == "text/xls")
            {
                downloadFileName = docTitle + ".xls";
            }
            else if (blockBlob.Properties.ContentType == "text/txt")
            {
                downloadFileName = docTitle + ".txt";
            }

            Response.AddHeader("Content-Disposition", "Attachment; filename=" + downloadFileName);
            Response.AddHeader("Content-Length", blockBlob.Properties.Length.ToString());
            Response.BinaryWrite(memStream.ToArray());


            LeadsManager lm = new LeadsManager();
            if (doc.LeadRequired.Trim() == "Yes")
            {

                // email document owner
                SmtpClient smtpClient = new SmtpClient("smtp.gmail.com", 25);

                smtpClient.Credentials = new System.Net.NetworkCredential("milderhlisondra@gmail.com", "025Zeus!Pinoy");
                // smtpClient.UseDefaultCredentials = true;
                smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtpClient.EnableSsl = true;
                MailMessage mail = new MailMessage();

                mail.Subject = "Your document has been downloaded";
                var messageBody = "The following document has been downloaded<br/><br/>";
                messageBody = messageBody + " " + doc.Title;
                messageBody = messageBody + " Downloaded by<br/><br/>";
                messageBody = messageBody + "First Name: " + lead.FirstName + "<br/>";
                messageBody = messageBody + "Last Name: " + lead.LastName + "<br/>";
                messageBody = messageBody + "Email: " + lead.Email + "<br/>";
                messageBody = messageBody + "Phone: " + lead.Phone + "<br/>";
                messageBody = messageBody + "Country: " + lead.Country + "<br/>";
                messageBody = messageBody + "Organization: " + lead.Organization + "<br/>";
                mail.Body = messageBody;
                mail.IsBodyHtml = true;
                //Setting From , To and CC
                mail.From = new MailAddress("milderhlisondra@gmail.com", "Coherent Document Management Portal");
                mail.To.Add(new MailAddress(emailToNotify));
                mail.CC.Add(new MailAddress("milder.lisondra@yahoo.com"));

                //smtpClient.Send(mail);
                // end email document owner

                var notificationInfo = new Dictionary<string, string>();
                notificationInfo.Add("subject", "Your document has been downloaded");
                notificationInfo.Add("message", messageBody);
                notificationInfo.Add("recipient", emailToNotify);
                notificationInfo.Add("recipientCC", "milder.lisondra@yahoo.com");

                lm.SendNotification(notificationInfo);
            }
            return View("Download");
        }

        // GET: Leads/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Leads/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Leads/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Leads/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult ListDocs()
        {
            var docs = db.Documents.SqlQuery("SELECT * FROM dbo.Documents").ToList();
            ViewBag.DocsList = docs;

            return View();
        }



        public ActionResult GetReferringUrl()
        {
            string referringUrl = Request.UrlReferrer.ToString();
            string referer = Request.Headers["Referer"].ToString();
            return Content(referer);
        }

        // GET
        // This is the action that would be used by EE to gain access into DMP
        // Requires username
        public ActionResult Gateway(string userName)
        {
            string message = Request.Params["username"];
            return Content(message);
        }


        public async System.Threading.Tasks.Task<ActionResult> ExportToSalesForce()
        {
            HttpClient client = new HttpClient();

            LeadsManager lm = new LeadsManager();

            string mystring = "The following Leads have been exported to Salesforce<br/><br/>";
            string downloadedDocs = "";
            string leadEmail = "";
            string leadFirstName = "";
            string leadLastName = "";
            string leadPhone = "";
            string leadCountry = "";
            string SFEndpoint = "";
            string appCodes = "";
            string productGroups = "";

            var uniqueIds = db.LeadsDownloads.Select(x => x.UID).Distinct().ToList();

            SFEndpoint = ConfigurationManager.AppSettings["SFEndpoint"];

            foreach (var item in uniqueIds)
            {
                downloadedDocs = ""; //reset variable
                appCodes = "";
                productGroups = "";

                if (item != 0)
                {
                    // get the lead information for current  UID
                    Leads leadInfo = db.Leads.Where(x => x.Id == item).FirstOrDefault();
                    mystring += leadInfo.FirstName + " " + leadInfo.LastName + " " + leadInfo.Email + "<br/>";
                    leadEmail = leadInfo.Email;
                    leadFirstName = leadInfo.FirstName;
                    leadLastName = leadInfo.LastName;
                    leadCountry = leadInfo.Country;
                    leadPhone = leadInfo.Phone;

                    // get leads with the current UID
                    var leads = db.LeadsDownloads.Where(x => x.UID == item).Where(x => x.SentStatus == "No").ToList();

                    // Check number of records in previous query
                    // If NOT greater than zero, skip all the logic below
                    if (leads.Count > 0)
                    {


                        List<int> leadsList = new List<int>();
                        foreach (var lead in leads)
                        {
                            downloadedDocs += lead.DocumentTitle + "\r\n"; // Include all Document titles downloaded by visitor

                            // Ensure that only the first App Code or Product Group is included in the data sent
                            if (appCodes == "")
                            {
                                appCodes += lead.AppCode;
                            }
                            if ( productGroups == "")
                            {
                                productGroups += lead.ProductGroup;
                            }
                            
                            mystring += lead.DocumentTitle + "<br/>";
                            leadsList.Add(lead.Id);

                        }


                        // setup key value pairs for SF
                        var values = new Dictionary<string, string>
                     {
                        { "debug", "1" },
                        { "debugEmail", "milder.lisondra@yahoo.com" },
                        {"oid", "00D300000006Iiv" },
                        {"lead_source", "Web to Lead" },
                        {"submit", "submit" },
                        {"retURL", "http://www.coherent.com/product/a" },
                        {"salutation", "" },
                        {"first_name", leadFirstName },
                        {"last_name", leadLastName },
                        {"email", leadEmail },
                        {"phone", leadPhone },
                        {"state", "" },
                        {"country", leadCountry },
                        {"member_status", "" },
                        {"company", "" },
                        {"fax", "" },
                        {"mobile", "" },
                        {"street", "" },
                        {"city", "" },
                        {"zip", "" },
                        {"Campaign_ID", "" },
                            {"00N40000001Q5XX", downloadedDocs },
                            {"00N40000001TXGZ", "" },
                            {"00N40000001x1tP", productGroups },
                            {"00N40000001Q4og", appCodes },

                     };



                        var content = new FormUrlEncodedContent(values);
                        var response = await client.PostAsync(SFEndpoint, content);

                        //update SentStatus for current LeadDownload
                        foreach (var leadItem in leadsList)
                        {
                            if (leadItem != 0)
                            {
                                var leadData = (from l in db.LeadsDownloads
                                                where l.Id == leadItem
                                                select l).FirstOrDefault();

                                leadData.SentStatus = "Yes";
                                int num = db.SaveChanges();
                            }

                        }

                    }
                    //leadsList.Clear();

                }

                mystring += "<br/><br/>";

            }
            return Content(mystring);
        }

        public JsonResult GetDocuments()
        {
            var documents = db.Documents.ToList();
            return Json(documents, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetCategories()
        {
            List<string> leadsList = new List<string>();
            leadsList.Add("Email Blast");
            leadsList.Add("Files");
            leadsList.Add("Assets");

            return Json(leadsList, JsonRequestBehavior.AllowGet);
        }
    }



}
