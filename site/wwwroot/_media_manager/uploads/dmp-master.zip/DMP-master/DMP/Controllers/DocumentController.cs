﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using System.Threading.Tasks;
using System.Web.Security;
using System.Text.RegularExpressions;

using DMP.Models.ViewModel;
using DMP.Models.EntityManager;
using System.Configuration;

using DMP.Models.DB;

using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using CoherentDMP.DMP.Models.DB;

namespace DMP.Controllers
{
    public class DocumentController : Controller
    {
        DMPEntities db = new DMPEntities();


        // GET: Document
        //[Authorize]
        public ActionResult Index()
        {
            if (User.Identity.IsAuthenticated)
            {
                Session["LoggedIn"] = "yes";
                ViewBag.LoggedIn = "yes";

                var docs = db.Documents.SqlQuery("SELECT * FROM dbo.Documents").ToList();
                ViewBag.DocsList = docs;

                return RedirectToAction("All", "Document"); // redirects to view with JQuery datatable
                //return View();
            } else  {
                return RedirectToAction("Login", "Account");
            }
 
        }

        // Get Document with given id
        public ActionResult Edit(int id)
        {
            // {
            if (User.Identity.IsAuthenticated)
            {
                Session["LoggedIn"] = "yes";
                ViewBag.LoggedIn = "yes";

                DocumentManager dm = new DocumentManager();

                var document = dm.GetDocument(id);

                EditDocumentView editView = new EditDocumentView();
                editView.AlternateTrackingId = document.AlternateTrackingId;
                editView.Title = document.Title;
                editView.Description = document.Description;
                editView.Category = document.Category;
                editView.Tags = document.Tags;
                editView.SalesForceId = document.SalesForceId;
                editView.AlternateTrackingId = document.AlternateTrackingId;
                editView.EndpointURL = document.EndpointURL;
                editView.FileName = document.FileName;
                editView.LeadRequired = document.LeadRequired.Trim();
                editView.EmailNotify = document.EmailNotify;
                return View(editView);

            }  else  {
                return RedirectToAction("Login", "Account");
            }

            // }         
        }

    

        [HttpPost]
        public ActionResult Edit(EditDocumentView doc)
        {
            if (User.Identity.IsAuthenticated)
            {
                Session["LoggedIn"] = "yes";
                ViewBag.LoggedIn = "yes";
            }
                if (ModelState.IsValid)
            {

                var docInfo = (from l in db.Documents
                                where l.Id == doc.Id
                                select l).FirstOrDefault();

                docInfo.Title = doc.Title.Trim();
                docInfo.Description = doc.Description;
                docInfo.Category = doc.Category;
                docInfo.Tags = doc.Tags;
                if ( String.IsNullOrEmpty( doc.SalesForceId) )
                {
                    docInfo.SalesForceId = doc.SalesForceId;
                }else
                {
                    docInfo.SalesForceId = doc.SalesForceId.Trim();
                }
                
                docInfo.AlternateTrackingId = doc.AlternateTrackingId;
                docInfo.LeadRequired = doc.LeadRequired.Trim();
                docInfo.EmailNotify = doc.EmailNotify;
                docInfo.ModifiedDateTime = DateTime.Now;
                int num = db.SaveChanges();

                ViewBag.notification = "Changes Saved";

                return RedirectToAction("DocumentDetails", new { id = doc.Id });
                //return View("Saved");
            }else
            {
                return View(doc);
            }
        }

        [HttpPost]
        public ActionResult DeleteDocument(int id)
        {
            Document doc = db.Documents.Find(id); // retrieve Document

            DocumentManager docManager = new DocumentManager();
            docManager.DeleteDocument(id); // delete Document from database

            CloudStorageAccount coherentStorageAccount = BlobConnectionString.GetConnectionString();
            CloudBlobClient blobClient = coherentStorageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference(doc.Category);
            CloudBlockBlob blockblob = container.GetBlockBlobReference(doc.FileName);
            blockblob.Delete(); // delete Document file from blob storage

            return Json(new { success = true, docfilename = doc.FileName });
        }

        //[Authorize]
        public ActionResult Add()
        {

            if (User.Identity.IsAuthenticated)
            {
                Session["LoggedIn"] = "yes";
                ViewBag.LoggedIn = "yes";
                return View();
            } else {
                return RedirectToAction("Login", "Account");
            }
        }

        //[HttpPost]
        [AcceptVerbs(HttpVerbs.Post)]
        public async Task<ActionResult> Add(UpdateDocumentView doc, HttpPostedFileBase file)
        {
            string cleanFileName;

            if (User.Identity.IsAuthenticated)
            {
                Session["LoggedIn"] = "yes";
                ViewBag.LoggedIn = "yes";
            }
                //Add validation if file is not present and fail model
                if (file == null)
            {
                ModelState.AddModelError("EndpointURL", "Please upload file");
            }

            if (ModelState.IsValid)
                {
                    if (file != null)
                    {

                        var fileName = Path.GetFileName(file.FileName);

                    // Clean up filename

                    cleanFileName = string.Join("-", fileName.Split(Path.GetInvalidFileNameChars()));
                    Regex regex_instance = new Regex("['%+_.?!]"); // Look for apostrophe, plus sign, underscore, period, question mark, exclamation mark
                    cleanFileName = regex_instance.Replace(doc.Title, ""); // Replace items from regex with no space

                    cleanFileName = Regex.Replace(cleanFileName, @"\s+", "-"); // Replace space with a dash ( - )
                    cleanFileName = cleanFileName + "-" + Guid.NewGuid().ToString() + Path.GetExtension(fileName); // Add a dash ( - ) between clean filename and GUID string                                                                                                                + Path.GetExtension(fileName); // append file extension

                    ImageService imageService = new ImageService();

                    string chosenCategory = doc.Category;
                    //MoveUploadedFile
                        string imageUrl = await imageService.MoveUploadedFile(file, cleanFileName, chosenCategory);
                        imageUrl = imageUrl.Replace("https://pocmarcomgolfstorage.blob.core.windows.net", ConfigurationManager.AppSettings["CoherentCDN"]);
                        ViewBag.message = imageUrl;
                        doc.EndpointURL = imageUrl;
                        
                        DocumentManager Doc = new DocumentManager();
                        doc.Filename = cleanFileName;
                        doc.CreatedBy = Convert.ToInt32(Session["loggedInUser"]); // Original
                        doc.CreatedBy = Convert.ToInt32(Session["userid"]); // Using the user id brought over from Expression Engine

                        int docid = Doc.AddDocument(doc);
                        TempData["imageUrl"] = imageUrl.Replace("https://pocmarcomgolfstorage.blob.core.windows.net", ConfigurationManager.AppSettings["CoherentCDN"]);

                    return RedirectToAction("DocumentDetails", new { id = docid });

                    }
                }
                
                return View();

        }


        public ActionResult UploadNew( int id)
        {
            Document doc = db.Documents.Find(id);
            
            return View();

        }

        /// <summary>
        /// Function to manage upload of new document revision
        /// </summary>
        /// <param name="id"></param>
        /// <param name="file"></param>
        /// <returns></returns>
        [AcceptVerbs(HttpVerbs.Post)]
        public async Task<ActionResult> UploadNew(int id, HttpPostedFileBase file)

        {
            var fileName = "";
            var movedFilename = "";
            var imageUrl = "";
            var blobContentType = "";

           

            if ( file != null)
            {
                fileName = Path.GetFileName(file.FileName);
                return Content(fileName);
            }
            return Content(fileName);

            //if (file != null)
            //{
            //    CloudStorageAccount coherentStorageAccount = BlobConnectionString.GetConnectionString();
            //    CloudBlobClient blobClient = coherentStorageAccount.CreateCloudBlobClient();


            //    //ModelState.AddModelError("EndpointURL", "Please upload file");

            //    DocumentManager dm = new DocumentManager();

            //    var document = dm.GetDocument(id);

            //    CloudBlobContainer srcContainer = blobClient.GetContainerReference(document.Category);
            //    CloudBlobContainer destContainer = blobClient.GetContainerReference("file-archive");

            //    // filename from database
            //    fileName = document.FileName;
            //    // get just filename without extension
            //    movedFilename = Path.GetFileNameWithoutExtension(fileName);

            //    // Move current file to archive container
            //    // The filename for the moved file will contain the current datetime appended to original filename
            //    CloudBlockBlob sourceBlob = srcContainer.GetBlockBlobReference(fileName);
            //    sourceBlob.FetchAttributes();
            //    blobContentType = sourceBlob.Properties.ContentType;

            //    DateTime curDateTime = DateTime.Now;
            //    string curDateTimeFormat = "MM-dd-yyy-HH-mm-ss";

            //    //Append current date time to file name for destination file
            //    movedFilename += curDateTime.ToString(curDateTimeFormat);

            //    if (blobContentType == "application/pdf")
            //    {
            //        movedFilename += ".pdf";
            //    }

            //    CloudBlockBlob targetBlob = destContainer.GetBlockBlobReference(movedFilename);
            //    await targetBlob.StartCopyAsync(sourceBlob);

            //    // Move new uploaded file into primary container
            //    ImageService imageService = new ImageService();
            //    imageUrl = await imageService.MoveUploadedFile(file, fileName, document.Category);

            //    TempData["imageUrl"] = imageUrl.Replace("https://pocmarcomgolfstorage.blob.core.windows.net", ConfigurationManager.AppSettings["CoherentCDN"]);
            //    return RedirectToAction("DocumentDetails");

            //}else
            //{
            //    return Content("no file");
            //}


        }

        /// <summary>
        /// 
        /// List all documents for blog container name given via uri
        /// </summary>
        /// <returns></returns>
        public ActionResult List( string id)
        {
            CloudStorageAccount coherentStorageAccount = BlobConnectionString.GetConnectionString();
            CloudBlobClient blobClient = coherentStorageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference(id);

            var listOfDocs = "";
            var urlToBlob = "";
            var downloadUrl = "";
            var fileName = "";
            var blobContentType = "";

            foreach (IListBlobItem item in container.ListBlobs(null, false))
            {
                if (item.GetType() == typeof(CloudBlockBlob))
                {
                    CloudBlockBlob blob = (CloudBlockBlob)item;
                    

                    urlToBlob = blob.Uri.ToString().Replace("https://pocmarcomgolfstorage.blob.core.windows.net", ConfigurationManager.AppSettings["CoherentCDN"]);

                    var sasToken = blob.GetSharedAccessSignature(new SharedAccessBlobPolicy()
                    {
                        Permissions = SharedAccessBlobPermissions.Read,
                        SharedAccessExpiryTime = DateTimeOffset.UtcNow.AddMinutes(15),
                    }, new SharedAccessBlobHeaders()
                    {
                        
                        ContentDisposition = "attachment; filename=\"" + blob.Name  + "\"",
                    });
                    downloadUrl = string.Format("{0}{1}", blob.Uri.AbsoluteUri, sasToken);//This URL will always do force download.
                    fileName = blob.Name;
                    blobContentType = blob.Properties.ContentType;

                }
                else if (item.GetType() == typeof(CloudPageBlob))
                {
                    CloudPageBlob pageBlob = (CloudPageBlob)item;
                    urlToBlob = pageBlob.Uri.ToString().Replace("https://pocmarcomgolfstorage.blob.core.windows.net", ConfigurationManager.AppSettings["CoherentCDN"]);

                    var sasToken = pageBlob.GetSharedAccessSignature(new SharedAccessBlobPolicy()
                    {
                        Permissions = SharedAccessBlobPermissions.Read,
                        SharedAccessExpiryTime = DateTimeOffset.UtcNow.AddMinutes(15),
                    }, new SharedAccessBlobHeaders()
                    {
                        ContentDisposition = "attachment; filename=\"" + pageBlob.Name + "\"",
                    });
                    downloadUrl = string.Format("{0}{1}", pageBlob.Uri.AbsoluteUri, sasToken);//This URL will always do force download.
                    fileName = pageBlob.Name;
                    blobContentType = pageBlob.Properties.ContentType;
                }

                // return Content(downloadUrl);


                listOfDocs +=  fileName + " <a href=\"" + downloadUrl  + "\">Download File</a>" + " "  + blobContentType;
                listOfDocs += "<br/><br/>";
            }
            ViewBag.listOfDocs = listOfDocs;

            return View();
        }

        public ActionResult All()
        {
            if (User.Identity.IsAuthenticated)
            {
                Session["LoggedIn"] = "yes";
                ViewBag.LoggedIn = "yes";

                var docs = db.Documents.SqlQuery("SELECT * FROM dbo.Documents").ToList();
                ViewBag.DocsList = docs;

                return View();
            }
            else
            {
                return RedirectToAction("Login", "Account");
            }

        }

        public ActionResult DocumentDetails( int id)
        {
            if (User.Identity.IsAuthenticated)
            {
                Session["LoggedIn"] = "yes";
                ViewBag.LoggedIn = "yes";
                ViewBag.Message = TempData["imageUrl"];

                DocumentManager dm = new DocumentManager();
                var doc = dm.GetDocument(id);
                
                ViewData["AlternateTrackingId"] = doc.AlternateTrackingId;
                ViewData["Title"] = doc.Title;
                ViewData["Description"] = doc.Description;
                if ( doc.Category == "assets" )
                {
                    ViewData["Category"] = "Assets";
                }
                else if( doc.Category == "emailblasts" )
                {
                    ViewData["Category"] = "Email Blasts";
                }
                else if (doc.Category == "files")
                {
                    ViewData["Category"] = "Files";
                }

                ViewData["Tags"] = doc.Tags;
                ViewData["SalesForceId"] = doc.SalesForceId;
                ViewData["AlternateTrackingId"] = doc.AlternateTrackingId;
                ViewData["EndpointURL"] = doc.EndpointURL;
                ViewData["FileName"] = doc.FileName;
                ViewData["LeadRequired"] = doc.LeadRequired.Trim();
                ViewData["EmailNotify"] = doc.EmailNotify;
                ViewData["CreatedBy"] = doc.CreatedBy;
                ViewData["AppCode"] = doc.AppCode;
                ViewData["ProductGroup"] = doc.ProductGroup;
                ViewData["CreatedDateTime"] = doc.CreatedDateTime;
                ViewData["ModifiedDateTime"] = doc.ModifiedDateTime;
                ViewData["DocId"] = doc.Id;
                return View();
            } else {
                return RedirectToAction("Login", "Account");
            }

        }

        public ActionResult DownloadFileAuto()
        {
            CloudStorageAccount coherentStorageAccount = BlobConnectionString.GetConnectionString();
            CloudBlobClient blobClient = coherentStorageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference("file");

            CloudBlockBlob blockBlob = container.GetBlockBlobReference("05551edc-4bd1-4c75-8f6d-24b68da01ad3.pdf");

            var docTitle = "file";
            var downloadFileName = "";

            MemoryStream memStream = new MemoryStream();
            blockBlob.DownloadToStream(memStream);
            Response.ContentType = blockBlob.Properties.ContentType;
            if (blockBlob.Properties.ContentType == "application/pdf")
            {
                downloadFileName = docTitle + ".pdf";
            }
            else if (blockBlob.Properties.ContentType == "application/zip")
            {
                downloadFileName = docTitle + ".zip";
            }
            Response.AddHeader("Content-Disposition", "Attachment; filename=" + downloadFileName);
            Response.AddHeader("Content-Length", blockBlob.Properties.Length.ToString());
            Response.BinaryWrite(memStream.ToArray());

            return Content("thanks");

        }
        public ActionResult DownloadSingleFile()
        {

            CloudStorageAccount coherentStorageAccount = BlobConnectionString.GetConnectionString();
            CloudBlobClient blobClient = coherentStorageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference("file");

            CloudBlockBlob blockBlob = container.GetBlockBlobReference("05551edc-4bd1-4c75-8f6d-24b68da01ad3.pdf");

            var sasToken = blockBlob.GetSharedAccessSignature(new SharedAccessBlobPolicy()
            {
                Permissions = SharedAccessBlobPermissions.Read,
                SharedAccessExpiryTime = DateTimeOffset.UtcNow.AddMinutes(15),
            }, new SharedAccessBlobHeaders()
            {
                ContentDisposition = "attachment; filename=\"somefile.pdf\"",
            });
            var downloadUrl = string.Format("{0}{1}", blockBlob.Uri.AbsoluteUri, sasToken);//This URL will always do force download.
            return Content(downloadUrl);
            
        }
        
        public ActionResult Download(int id)
        {
            Document doc = db.Documents.Find(id);
            if( doc.LeadRequired.Trim() == "Yes")
            {
                return Content("show lead form");
            }
            else
            {
                return RedirectToAction("DownloadSingleFile", "Document");
            }

        }


        /// <summary>
        /// Download from local /App_data/uploads
        /// </summary>
        /// <param name="ImageName"></param>
        /// <returns></returns>
        public FileResult DownloadFromLocal(string ImageName)
        {
            var FileVirtualPath = "~/App_Data/uploads/" +ImageName;
            return File(FileVirtualPath, "application/force-download", Path.GetFileName(FileVirtualPath));
        }

        public ActionResult CopyBlob()
        {
            CloudStorageAccount coherentStorageAccount = BlobConnectionString.GetConnectionString();
            CloudBlobClient blobClient = coherentStorageAccount.CreateCloudBlobClient();
            CloudBlobContainer src_container = blobClient.GetContainerReference("file");
            CloudBlobContainer dest_container = blobClient.GetContainerReference("file-archive");

            CloudBlockBlob srcblockBlob = src_container.GetBlockBlobReference("34f9d75b-268a-4bfb-8104-646c7b51f858.pdf");

            var blob_name_no_extension = Path.GetFileNameWithoutExtension(srcblockBlob.Name);

            var current_date = DateTime.Now.ToString().Replace("/","");
            current_date = current_date.Replace(":", "");
            current_date = current_date.Replace(" ", "");
            var copied_blob_name = blob_name_no_extension + "-" + current_date + Path.GetExtension(srcblockBlob.Name);

            CloudBlockBlob destblockBlob = dest_container.GetBlockBlobReference(copied_blob_name);
            
            destblockBlob.StartCopy(srcblockBlob);
            
            return Content(copied_blob_name);
        }

        public ActionResult ListAppCodes()
        {
            var appcodes = db.AppCodes.ToList();
            var mystring = "";
            foreach (var item in appcodes)
            {
               // mystring += "<option value=\"" + item.Code + "\">";
               // mystring += item.Code + " " + item.Description;
               // mystring += "</option>";

               mystring += "new SelectListItem { Text=\"(" + item.Code + ")" + " " + item.Description + "\", Value=\"" + item.Code + "\" },";
                mystring += "\r\n";
            }
            //new SelectListItem { Text="Compass", Value="Compass" },
            return Content(mystring);
        }

        public ActionResult GetAllAppCodes()
        {
            if (User.Identity.IsAuthenticated)
            {
                Session["LoggedIn"] = "yes";
                ViewBag.LoggedIn = "yes";

                var appcodes = db.AppCodes.ToList();
                ViewBag.AppCodesList = appcodes;

                return View();

            }
            else
            {
                return RedirectToAction("Login", "Account");
            }
        }

        public ActionResult AddNewAppCode()
        {
            if (User.Identity.IsAuthenticated)
            {
                Session["LoggedIn"] = "yes";
                ViewBag.LoggedIn = "yes";

                DocumentManager Doc = new DocumentManager();
                Doc.AddAppCode();
                return View();
            }
            else
            {
                return RedirectToAction("Login", "Account");
            }

           
        }

    }
}