Tracking Breaking changes in 1.0.0

* Removed `dataSerializer` parameter from `BlobRextProxy` constructor.
* Option parameter type of `BlobRestProxy::CreateBlockBlob` and `BlobRestProxy::CreatePageBlobFromContent` changed and added `setUseTransactionalMD5` method.
* Deprecated PHP 5.5 support.