﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace DMP.Models.ViewModel
{
    public class AddAppCode
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "* Required")]
        [Display(Name = "App Code")]
        public string Title { get; set; }

        [Required(ErrorMessage = "* Required")]
        [Display(Name = "Description")]
        public string Description { get; set; }

    }

    public class EditAppCode
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "* Required")]
        [Display(Name = "App Code")]
        public string Title { get; set; }

        [Required(ErrorMessage = "* Required")]
        [Display(Name = "Description")]
        public string Description { get; set; }

    }

    public class UpdateDocumentView
    {

        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "* Title required")]
        [Display(Name = "Title")]
        public string Title { get; set; }

        [Display(Name = "Description")]
        public string Description { get; set; }

        [Required(ErrorMessage = "* Category required")]
        [Display(Name = "Category")]
        public string Category { get; set; }

        public string Tags { get; set; }
        public string SalesForceId { get; set; }
        public string AlternateTrackingId { get; set; }
        public string Filename { get; set; }
        [Display(Name = "EndpointURL")]
        public string EndpointURL { get; set; }

        [Required(ErrorMessage = "* Select one")]
        [Display(Name = "Lead Form Required?")]
        public string LeadRequired { get; set; }

        public string EmailNotify { get; set; }
        public int CreatedBy { get; set; }

        [Display(Name = "Product Group")]
        public string ProductGroup { get; set; }

        [Display(Name = "App Code")]
        public string AppCode { get; set; }

    }

    public class ProductCodes
    {
        public string Code { get; set; }
        public string Description { get; set; }
    }


    public class EditDocumentView
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "* Title required")]
        [Display(Name = "Title")]
        public string Title { get; set; }

        [Display(Name = "Description")]
        public string Description { get; set; }

        [Required(ErrorMessage = "* Category required")]
        [Display(Name = "Category")]
        public string Category { get; set; }

        public string Tags { get; set; }
        public string SalesForceId { get; set; }
        public string AlternateTrackingId { get; set; }

        [Display(Name = "EndpointURL")]
        public string EndpointURL { get; set; }

        [Required(ErrorMessage = "* Select one")]
        [Display(Name = "Lead Form Required?")]
        public string LeadRequired { get; set; }

        public int UserId { get; set; }
        public string FileName { get; set; }
        public string EmailNotify { get; set; }

    }

    public class UpdateDocument {

        [Key]
        public int Id { get; set; }

        [Display(Name = "EndpointURL")]
        public string EndpointURL { get; set; }
    }



}